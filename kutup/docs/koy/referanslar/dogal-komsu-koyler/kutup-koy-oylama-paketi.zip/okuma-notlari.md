# Kütüp köy düzeni karşılaştırması

## Paketi açma
`oylama.html` tek başına, internet olmadan açılır. Düzen ve büyüklük seçilir; sahiplik işaretleri açılıp kapatılabilir. Oy metni yerel olarak hazırlanır; hiçbir yere gönderilmez. Kolay paylaşım için `kutup-15-senaryo.pdf`; düzenlenebilir çizimler için `svg/`; mesajlaşmada paylaşılabilir görseller için `png/` kullanılır.

## Beş yaklaşım
A — Eski kişisel mahalleler. Eski kodun kişisel hücreleri ve genişleme davranışı.
B — Mevcut ortak köy. İncelenen yeni kodun ortak sokakları ve karışık sahiplik dokusu.
C — Doğal komşu köyler. Kişisel merkezler, kısa doğal boşluklar, kıvrımlı ana dere ve gölle bağlantılı yan kol.
D — Ortak çayır çevresinde köyler. Paylaşılan yeşil merkez, çevresinde kişisel merkezler, dışa büyüme.
E — Dere boyunca kıyı köyleri. Nehir boyunca yakın yerleşimler ve karşılıklı kıyı bağlantıları.

## Eşit tutulanlar
Dört örnek kişi, aynı bina kataloğu ve eklenme sırası; toplam hedefler 47 / 200 / 500. Dağılımlar sırasıyla 17-13-10-7, 65-50-45-40, 250-120-80-50. Yeni aşamalar önceki envanterin devamıdır. Aynı aşamada kamera ölçeği bütün seçeneklerde eşit; kadraj merkezi her yerleşime göre değişir. Bütün yakın görünüm kutuları aynı ölçeklidir. Tek bir gündüz paleti kullanılır; gece efektleri oylamayı etkilemez.

## Kanıtın sınırı
A/B yerleşim koordinatları gerçek kaynak kodundaki planlayıcılar çalıştırılarak, sentetik envanter ve `kutup-oylama-2026` tohumu ile elde edildi. Bunlar canlı veritabanının kopyası veya uygulama ekran görüntüsü değildir. İncelenen sürüm: a2ef2311c141b13c543e73bcb3eba3dd7d1f5b1d. Kodun aktif yerleşim yaklaşımını temsil eder; üretimde hangi sürümün dağıtıldığı ayrıca doğrulanmadı.

B'de bu örnek Süleymaniye yapısı (`b37`) için yer bulunamadı. Gerçekte gösterilen bina sayıları 46 / 199 / 499. İkinci Süleymaniye sonraki aşamada yerleşti. Bu bulgu tek tohumla sınırlıdır. Eksik bina için uydurma koordinat eklenmedi.

Bina vektörleri projedeki `src/iso.js` ve özel bina çizimlerinden üretildi. A/B bina ve sokak geometrisi koddan gelir; sunum ağaçları, köprü çizimleri, kişisel isim etiketlerinin görünümü ve açıklamalar şematiktir. C/D/E için bu görseller bir üretim planlayıcısının doğrulanmış sonucu değildir; tasarım yönünü karşılaştırmak amacıyla programla hazırlanmış taslaklardır. Geçit sayısı, araziye erişim, eğim ve genişleme adaleti henüz çözülmüş sayılmaz.

500 bina çizimi mobil performans ölçümü değildir. Uygulama seçildiğinde görünür alan kırpma, ayrıntı seviyeleri, animasyon bütçesi ve gerçek cihaz ölçümü gerekir. Bu çalışma uygulama kodunu değiştirmez.

## Oylama yöntemi
Önce 47 binayı sahiplik noktaları kapalı inceleyin. Kimin neresi olduğu seçiliyor mu? Sonra 200 ve 500 binayı karşılaştırın. Noktaları açarak sezginizi kontrol edin. Birinci ve ikinci tercihinizi ve değiştirmek istediğiniz tek şeyi yazın. Renkli noktalar karşılaştırma aracıdır, aktif ürün özelliği olduğu iddia edilmez.
